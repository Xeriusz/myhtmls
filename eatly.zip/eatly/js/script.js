let img = document.querySelector('#dish-1');
let img2 = document.querySelector('#dish-2');
let btn1 = document.querySelector('#button-a-1');
let btn2 = document.querySelector('#button-a-2');
let btn3 = document.querySelector('#button-a-3');
let btn4 = document.querySelector('#button-a-4');
let btn5 = document.querySelector('#button-a-5');
let btn6 = document.querySelector('#button-a-6');
let btn7 = document.querySelector('#button-a-7');
let btn8 = document.querySelector('#button-a-8');

btn1.addEventListener('click', () => {
    img.src = 'img/dish-1.jpg';
    img2.src = 'img/dish-2.jpg';
})

btn2.addEventListener('click', () => {
    img.src = 'img/dish-3.jpg';
    img2.src = 'img/dish-4.jpg';
})

btn3.addEventListener('click', () => {
    img.src = 'img/dish-6.jpg';
    img2.src = 'img/dish-5.jpg';
})

btn4.addEventListener('click', () => {
    img.src = 'img/dish-7.jpg';
    img2.src = 'img/dish-8.jpg';
})

btn5.addEventListener('click', () => {
    img.src = 'img/dish-9.jpg';
    img2.src = 'img/dish-10.jpg';
})

btn6.addEventListener('click', () => {
    img.src = 'img/dish-11.jpg';
    img2.src = 'img/dish-12.jpg';
})

btn7.addEventListener('click', () => {
    img.src = 'img/dish-15.jpg';
    img2.src = 'img/dish-16.jpg';
})

btn8.addEventListener('click', () => {
    img.src = 'img/dish-13.jpg';
    img2.src = 'img/dish-14.jpg';
})